﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TicTacToe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe.Tests
{
    [TestClass()]
    public class TicTacToeTests
    {
        [TestMethod()]
        public void TestActiveFields()
        {
            
        }

        [TestMethod()]
        public void CreateBoardTest()
        {
            string[,] Expected = new string[3, 3];
            TicTacToe testGame = new TicTacToe();
            testGame.CreateBoard();
            var result = testGame.GameBoard;
            Assert.AreEqual(9, 9);
        }

        [TestMethod()]
        public void CurrentPlayerTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void ChangePlayerTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void MakeMoveTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void SpaceInUseTest()
        {
            Assert.Fail();
        }
        /*
[TestMethod()]
public void CurrentPlayerTest()
{
TicTacToe testGame = new TicTacToe();
testGame.CreateBoard();

Assert.Fail();
}
*/
    }
}