﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    public class TicTacToe
    {
        static string playerX = " X ";
        static string playerO = " O ";

        bool isPlayerX = true;
        bool isPlayerO = false;

        string input;

        string[,] gameBoard = new string[3, 3] { {"[ ]", "[ ]", "[ ]" },
                                                 {"[ ]", "[ ]", "[ ]" },
                                                 {"[ ]", "[ ]", "[ ]" } };

        public string[,] GameBoard
        {
            get
            {
                return gameBoard;
            }

            set
            {
                gameBoard = value;
            }
        }
        public void CreateBoard()
        {
            int row = gameBoard.GetLength(0);
            int col = gameBoard.GetLength(1);
            for (int i = 0; i < row; i++)
            {
                Console.Write('\n');
                for (int j = 0; j < col; j++)
                {
                    Console.Write(gameBoard[i, j]);
                }
            }
            input = Console.ReadLine();
            CurrentPlayer();
            MakeMove(input);

        }

        public string CurrentPlayer()
        {
            string player = "";

            if (isPlayerX == true)
            {
                Console.WriteLine("Current player is X");
                player = "X";
            }
            if (isPlayerO == true)
            {
                Console.WriteLine("Current player is O");
                player = "O";
            }
            return player;
        }

        public void ChangePlayer()
        {
            if (isPlayerX == true && isPlayerO == false)
            {
                isPlayerX = false;
                isPlayerO = true;
            }
            else if (isPlayerX == false && isPlayerO == true)
            {
                isPlayerX = true;
                isPlayerO = false;
            }
        }

        public void MakeMove(string input)
        {
            string x = input.Substring(0, 1);
            string y = input.Substring(2, 1);
            int i = Int32.Parse(x);
            int j = Int32.Parse(y);

            if (isPlayerX == true)
            {
                gameBoard[i, j] = playerX;
            }
            if (isPlayerO == true)
            {
                gameBoard[i, j] = playerO;
            }
            ChangePlayer();
            CreateBoard();
        }

        public bool SpaceInUse(int i, int j)
        {
            if (gameBoard[i, j] != "[ ]")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
