﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void CreateBoardTest()
        {
            string[,] Expected = new string[3, 3];
            TicTacToe testGame = new TicTacToe();
            testGame.CreateBoard();
            var result = testGame.GameBoard;
            Assert.AreEqual(9, 9);
        }
    }
}
