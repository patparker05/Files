﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TicTacToe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe.Tests
{
    [TestClass()]
    public class TicTacToeTests
    {
        [TestMethod()]
        public void ActiveFieldsTest()
        {
            TicTacToe game = new TicTacToe();

            Assert.AreEqual(9, game.GameBoard.Length);
        }

        [TestMethod()]
        public void CurrentPlayerIsX()
        {
            TicTacToe game = new TicTacToe();
            Assert.IsTrue(game.CurrentPlayer() == "X");
        }

        [TestMethod()]
        public void CurrentPlayerIsO()
        {
            TicTacToe game = new TicTacToe();
            Assert.IsTrue(game.CurrentPlayer() == "O");
        }

        [TestMethod()]
        public void PlayerPlacedX(int i, int j)
        {
            TicTacToe game = new TicTacToe();
            Assert.IsTrue(game.GameBoard[i, j] == "X");
        }

        [TestMethod()]
        public void SpaceInUseTest(int i, int j)
        {
            TicTacToe game = new TicTacToe();
            Assert.IsTrue(game.SpaceInUse(i, j) == false);
        }

        [TestMethod()]
        public void PlayerPlacedO(int i, int j)
        {
            TicTacToe game = new TicTacToe();
            Assert.IsTrue(game.GameBoard[i, j] == "O");
        }


    }
}