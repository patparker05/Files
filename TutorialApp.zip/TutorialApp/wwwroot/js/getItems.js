﻿var itemList = [];
var keys = Object.keys(localStorage);
var listLength = keys.length;

var page = document.getElementById("cardSets");
console.log(page);

function getItems() {

    for (var i = 0; i < listLength; i++) {
        if (itemList[i] != localStorage.getItem(keys[i])) {
            itemList.push(JSON.parse(localStorage.getItem(keys[i])));
        }
    }

    var container = document.createElement('div');
    container.classList.add("container"); 

    for (var i = 0; i < itemList.length; i++) {
        console.log(keys[i]);
        var title = document.createElement("h3");
        title.innerHTML = keys[i];
        container.appendChild(title);

        var btn = document.createElement("button");
        btn.innerHTML = "view";
        btn.classList.add("btn");
        container.appendChild(btn);
        btn.addEventListener("click", handleView);
    }
    console.log(container);
    console.log(document.getElementById("cardSets"));
    document.getElementById("cardSets").appendChild(container);
}

function handleView(event) {
    var titleHeader = document.createElement("h3");
    titleHeader.innerHTML = event.target.previousSibling.innerHTML;
    console.log("event fired");
    document.getElementById("cardSets").innerHTML = "";
    document.getElementById("cardSets").appendChild(titleHeader);
    for (var i = 0; i < listLength; i++) {
        if (keys[i] == titleHeader.innerHTML) {

            for (var j = 0; j < itemList[i].length; j++) { 
                var term = document.createElement("h6");
                console.log(itemList[i]);
                term.innerHTML = "Term: " + itemList[i][j].term;
                console.log(itemList[i][j].term);
                document.getElementById("cardSets").appendChild(term);

                var definition = document.createElement("div");

                definition.innerHTML = "Definition: " + "<br/>" + itemList[i][j].definition + "<hr/>";
    
                document.getElementById("cardSets").appendChild(definition);
            }
        }
    }
    var backButton = document.createElement("button");
}