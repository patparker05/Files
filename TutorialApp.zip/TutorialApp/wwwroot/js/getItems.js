﻿
var itemList = [];
var keys = Object.keys(localStorage);
var listLength = keys.length;


function getItems() {

    for (var i = 0; i < listLength; i++) {
        if (itemList[i] != localStorage.getItem(keys[i])) {
            itemList.push(JSON.parse(localStorage.getItem(keys[i])));
        }
    }
    console.log(itemList);

    var container = document.createElement('div');
    container.classList.add("container");
    container.classList.add("mt-3");

    for (var i = 0; i < itemList.length; i++) {
        console.log(keys[i]);
        var title = document.createElement("h3");
        title.innerHTML = keys[i];
        container.appendChild(title);

        var btn = document.createElement("button");
        btn.innerHTML = "view";
        btn.classList.add("btn", "btn-secondary");
        container.appendChild(btn);
        container.appendChild(document.createElement("hr"));
        btn.addEventListener("click", handleView);
    }
    console.log(container);
    console.log(document.getElementById("cardSets"));
    document.getElementById("cardSets").appendChild(container);
}

function handleView(event) {
    var titleHeader = document.createElement("h3");
    titleHeader.innerHTML = event.target.previousSibling.innerHTML;
    console.log("event fired");
    document.getElementById("cardSets").innerHTML = "";
    document.getElementById("cardSets").appendChild(titleHeader);

    for (var i = 0; i < listLength; i++) {
        if (keys[i] == titleHeader.innerHTML) {

            for (var j = 0; j < itemList[i].length; j++) { 
                var flashcardContainer = document.createElement("div");
                flashcardContainer.classList.add("card-container");
                var flashcard = document.createElement("div");
                flashcard.classList.add("flashcard");
                flashcardContainer.appendChild(flashcard);
                document.getElementById("cardSets").appendChild(flashcardContainer);

                var term = document.createElement("div");
                term.classList.add("flashcard-front");
                console.log(itemList[i]);
                term.innerHTML = "Term: " + "<br/>" + itemList[i][j].term;
                console.log(itemList[i][j].term);
                flashcard.appendChild(term);

                var definition = document.createElement("div");
                definition.classList.add("flashcard-back");
                definition.innerHTML = itemList[i][j].definition;
                flashcard.appendChild(definition);
            }
        }
    }
    //var backLink = document.createElement("a");
    //backLink.href = "mysets";
    var backButton = document.createElement("button");
    backButton.classList.add("btn", "btn-secondary", "mt-2");
    backButton.innerHTML = "Go Back";
    backButton.onclick = function () {
        location.reload();
    }
    //backLink.appendChild(backButton);
    document.getElementById("cardSets").appendChild(backButton);

    var testButton = document.createElement("button");
    testButton.classList.add("btn", "btn-secondary", "mt-2", "offset-md-3");
    testButton.innerHTML = "Create Test";
    testButton.onclick = createTest;
    document.getElementById("cardSets").appendChild(testButton);
}

class TestQuestion {
    constructor(question, answer) {
        this.question = question;
        this.answer = answer;
    }
}

function createTest() {
    var testList = [];
    var header = document.querySelectorAll("h3");
    for (var i = 0; i < listLength; i++) {
        if (keys[i] == header[0].innerHTML) {
            for (var j = 0; j < itemList[i].length; j++) {
                var newTQ = new TestQuestion();
                newTQ.answer = itemList[i][j].term;
                newTQ.question = itemList[i][j].definition;
                testList.push(newTQ);
            }
            sessionStorage.setItem(keys[i], JSON.stringify(testList));
        }
    }
}