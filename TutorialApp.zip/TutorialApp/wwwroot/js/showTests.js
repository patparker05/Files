﻿
function getTests() {
    var testList = [];
    var keys = Object.keys(sessionStorage);
    var listLength = keys.length;

    for (var i = 0; i < listLength; i++) {
        testList.push(JSON.parse(sessionStorage.getItem(keys[i])));
    }

    var container = document.createElement('div');
    container.classList.add("container");
    container.classList.add("mt-3");

    for (var i = 0; i < listLength; i++) {
        var title = document.createElement("h3");
        title.innerHTML = keys[i];
        container.appendChild(title);

        var btn = document.createElement("button");
        btn.innerHTML = "Take Test";
        btn.classList.add("btn", "btn-secondary");
        container.appendChild(btn);
        container.appendChild(document.createElement("hr"));
        btn.addEventListener("click", handleTest);

        document.getElementById("tests").appendChild(container);
    }
    console.log(testList);
}

function handleTest(event) {
    var testList = [];
    var keys = Object.keys(sessionStorage);
    var listLength = keys.length;

    for (var i = 0; i < listLength; i++) {
        testList.push(JSON.parse(sessionStorage.getItem(keys[i])));
    }

    var titleHeader = document.createElement("h3");
    titleHeader.innerHTML = event.target.previousSibling.innerHTML;
    console.log("event fired");
    document.getElementById("tests").innerHTML = "";
    document.getElementById("tests").appendChild(titleHeader);

    for (var i = 0; i < listLength; i++) {
        if (keys[i] == titleHeader.innerHTML) {

            for (var j = 0; j < testList[i].length; j++) {
                var container = document.createElement('div');
                container.classList.add("container");
                container.classList.add("mt-3");
                
                var question = document.createElement("label");
                question.classList.add("mb-3");
                question.innerHTML = testList[i][j].question + "?";
                console.log(testList[i][j].question);
                container.appendChild(question);

                var userAnswer = document.createElement("input");
                userAnswer.type = "text";
                userAnswer.classList.add("form-control");
                //definition.innerHTML = testList[i][j].definition;
                container.appendChild(userAnswer);

                var submitBtn = document.createElement("button");
                submitBtn.innerHTML = "submit";
                submitBtn.classList.add("btn", "btn-secondary", "mt-2");
                submitBtn.id = "btn" + (j + 1);
                container.appendChild(submitBtn);

                document.getElementById("tests").appendChild(container);
            }
        }
    }
    handleButtons();
}

function handleButtons() {
    var testList = [];
    var keys = Object.keys(sessionStorage);
    var listLength = keys.length;

    for (var i = 0; i < listLength; i++) {
        testList.push(JSON.parse(sessionStorage.getItem(keys[i])));
    }

    var buttons = document.querySelectorAll("button");
    var labels = document.querySelectorAll("label");
    var header = document.querySelector("h3");
    console.log(header.innerHTML);
    console.log(buttons);

    for (var k = 1; k < buttons.length; k++) {
        if (("btn" + k) == buttons[k].id) {
            buttons[k].addEventListener('click', function () {
                var currentQuestion = this.previousSibling.previousSibling.innerHTML.slice(0, -1);
                var currentAnswer = this.previousSibling.value;
                console.log("current answer: " + currentAnswer);
                for (var i = 0; i < listLength; i++) {
                    if (keys[i] == header.innerHTML) { 
                        console.log(testList[i]);
                        for (var j = 0; j < testList[i].length; j++) {
                            console.log("question: " + testList[i][j].question);
                            if (testList[i][j].question == currentQuestion) {
                                console.log(testList[i][j].question);
                                if (testList[i][j].answer == currentAnswer) {

                                    alert("That's Correct!");

                                }
                                else {
                                    alert("Try again");
                                }
                            }
                        }
                    }
                }
            });
        }
    }
}
