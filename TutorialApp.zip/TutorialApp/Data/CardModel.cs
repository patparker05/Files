﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace TutorialApp.Data
{
    public class CardModel
    {
        [Required]
        public string term { get; set; }

        [Required]
        public string definition { get; set; }
    }
}
